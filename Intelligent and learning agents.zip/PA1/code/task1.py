"""
NOTE: You are only allowed to edit this file between the lines that say:
    # START EDITING HERE
    # END EDITING HERE

This file contains the base Algorithm class that all algorithms should inherit
from. Here are the method details:
    - __init__(self, num_arms, horizon): This method is called when the class
        is instantiated. Here, you can add any other member variables that you
        need in your algorithm.
    
    - give_pull(self): This method is called when the algorithm needs to
        select an arm to pull. The method should return the index of the arm
        that it wants to pull (0-indexed).
    
    - get_reward(self, arm_index, reward): This method is called just after the 
        give_pull method. The method should update the algorithm's internal
        state based on the arm that was pulled and the reward that was received.
        (The value of arm_index is the same as the one returned by give_pull.)

We have implemented the epsilon-greedy algorithm for you. You can use it as a
reference for implementing your own algorithms.
"""

import numpy as np
import math
# Hint: math.log is much faster than np.log for scalars

class Algorithm:
    def __init__(self, num_arms, horizon):
        self.num_arms = num_arms
        self.horizon = horizon
    
    def give_pull(self):
        raise NotImplementedError
    
    def get_reward(self, arm_index, reward):
        raise NotImplementedError

# Example implementation of Epsilon Greedy algorithm
class Eps_Greedy(Algorithm):
    def __init__(self, num_arms, horizon):
        super().__init__(num_arms, horizon)
        # Extra member variables to keep track of the state
        self.eps = 0.1
        self.counts = np.zeros(num_arms)
        self.values = np.zeros(num_arms)
    
    def give_pull(self):
        if np.random.random() < self.eps:
            return np.random.randint(self.num_arms)
        else:
            return np.argmax(self.values)
    
    def get_reward(self, arm_index, reward):
        self.counts[arm_index] += 1
        n = self.counts[arm_index]
        value = self.values[arm_index]
        new_value = ((n - 1) / n) * value + (1 / n) * reward
        self.values[arm_index] = new_value


# START EDITING HERE
# You can use this space to define any helper functions that you need
def kldiv(x,y):
#    for safe side to avoid term inside ln becoming 0 add a small number
   return x*math.log(1e-9+x/y)+(1-x)*math.log(1e-9+(1-x)/(1-y))
def BinSearch(t,val):
    p=t 
    iterations=10
    low=t 
    high=0.999
    for i in range(iterations):
        mid=(low+high)/2
        compare=kldiv(t,mid)-val
        if(abs(compare)<0.01):
            return mid
        elif(compare>0): 
            high=mid 
        else:
            low=mid 
    return mid
# END EDITING HERE

class UCB(Algorithm):
    def __init__(self, num_arms, horizon):
        super().__init__(num_arms, horizon)
        # You can add any other variables you need here
        # START EDITING HERE
        self.empirical_mean = np.zeros(num_arms)
        self.pulls_to_arm    = np.ones(num_arms)
        self.ucb            = np.zeros(num_arms)
        # Sum of all arms pulled/t 
        # sum_of_elements = np.sum(self.pulls_to_arm)
        # END EDITING HERE
    
    def give_pull(self):
        # START EDITING HERE
        # arm which has highest ucb is pulled and ties are broken uniformly at random
        # max_ucb= self.np.max(ucb) gave error 
        # Find max value in ucb
        max_ucb= np.max(self.ucb)
        # find indices where maximum value occurs
        max_indices=np.where(self.ucb==max_ucb)[0]
        # break ties uniformly at random if any
        arm_to_pull=np.random.choice(max_indices)
        return arm_to_pull
        # END EDITING HERE
    
    def get_reward(self, arm_index, reward):
        # START EDITING HERE
        """ pass """#why is pass here
        """
        Increase ++ pull to arm which was pulled
        Update empirical mean for the arm pulled
        Update all the ucbs
        """
        self.pulls_to_arm[arm_index] += 1

        n = self.pulls_to_arm[arm_index]
        value = self.empirical_mean[arm_index]
        new_value = ((n - 1) / n) * value + (1 / n) * reward
        self.empirical_mean[arm_index] = new_value
        # +1 imp
        sqrt_term=2*math.log(np.sum(self.pulls_to_arm)+1)/self.pulls_to_arm
        self.ucb = self.empirical_mean + sqrt_term
        self.ucb[np.isnan(self.ucb)] = np.inf
        # END EDITING HERE
""" sqrt_term = 2 * math.log(np.sum(pulls_to_arm)) / pulls_to_arm

# Calculate ucb based on empirical_mean and the square root term
ucb = empirical_mean + np.sqrt(sqrt_term) """
""" http://proceedings.mlr.press/v19/garivier11a/garivier11a.pdf
     correct algo slide:incomplete """
class KL_UCB(Algorithm):
    
    def __init__(self, num_arms, horizon):
        super().__init__(num_arms, horizon)
        # You can add any other variables you need here
        # START EDITING HERE
        self.empirical_mean = np.zeros(num_arms)
        self.pulls_to_arm   = np.ones(num_arms)*2
        self.klucb          = np.zeros(num_arms)
        """ Problem Faced domain for RHS of klucb
         so initialising t from 2 and introducing new
          variable """
        self.horizon=2
        # END EDITING HERE
    
    def give_pull(self):
        # START EDITING HERE
        self.horizon+=1
        return np.argmax(self.klucb)   
# returns first index encountered if multiple indexes 
# in ucb ties broken uniformly at random
        # END EDITING HERE
    
    def get_reward(self, arm_index, reward):
        # START EDITING HERE
        """increase pulls 
        update empirical probability of arm pulled
        update all the klucbs 
          """
        self.pulls_to_arm[arm_index]+=1
        n = self.pulls_to_arm[arm_index]
        value = self.empirical_mean[arm_index]
        new_value = ((n - 1) / n) * value + (1 / n) * reward
        self.empirical_mean[arm_index] = new_value
    #    t which is horizon is increased don't worry about it
        for i in range(self.num_arms):
            target=(math.log(self.horizon)+3*math.log(math.log(self.horizon)))/(self.pulls_to_arm[arm_index])
            self.klucb[i]=BinSearch(self.empirical_mean[i],target)
        
        # pass
        # END EDITING HERE


class Thompson_Sampling(Algorithm):
    def __init__(self, num_arms, horizon):
        super().__init__(num_arms, horizon)
        # You can add any other variables you need here
        # START EDITING HERE
        self.sucess    =np.zeros(num_arms)
        self.failures  =np.zeros(num_arms)
        self.beta_samples=np.zeros(num_arms)
        # END EDITING HERE
    
    def give_pull(self):
        # START EDITING HERE
        self.beta_samples=np.random.beta(self.sucess+1,self.failures+1)
        return np.argmax(self.beta_samples)
        # END EDITING HERE
    
    def get_reward(self, arm_index, reward):
        # START EDITING HERE
        self.sucess[arm_index]+=reward
        self.failures[arm_index]+=1-reward
        # END EDITING HERE
